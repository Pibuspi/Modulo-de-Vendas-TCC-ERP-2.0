/**package controller;

import model.ResultadoPrecificacao;
import model.ResultadoPrecificacao.StatusAprovacao;

/** Matheus Godoy: motor de margens, alçadas e bloqueios da venda. 
public class PricingEngineController {
    public static final double DESCONTO_AUTOMATICO_MAXIMO = 5.0;
    public static final double DESCONTO_GERENTE_MAXIMO = 10.0;

    /** Calcula margem real: (preço praticado - custo) / preço praticado * 100. 
    public ResultadoPrecificacao validarMargemLucro(double custo, double precoVenda, double desconto) {
        if (custo < 0 || precoVenda <= 0 || desconto < 0) {
            return resultado(precoVenda, desconto, -100.0, StatusAprovacao.HARD_STOP, "Valores de custo, preço ou desconto inválidos.");
        }
        double precoPraticado = precoVenda * (1.0 - desconto / 100.0);
        double margemReal = precoPraticado <= 0 ? -100.0 : ((precoPraticado - custo) / precoPraticado) * 100.0;
        StatusAprovacao status;
        String justificativa;
        if (desconto > DESCONTO_GERENTE_MAXIMO || margemReal < 0) {
            status = StatusAprovacao.HARD_STOP;
            justificativa = "Desconto acima de 10% ou margem real negativa.";
        } else if (desconto > DESCONTO_AUTOMATICO_MAXIMO) {
            status = StatusAprovacao.PENDENTE_APROVACAO;
            justificativa = "Desconto exige parecer e aprovação gerencial.";
        } else {
            status = StatusAprovacao.LIBERADO;
            justificativa = "Operação liberada automaticamente.";
        }
        return resultado(precoPraticado, desconto, margemReal, status, justificativa);
    }

    private ResultadoPrecificacao resultado(double preco, double desconto, double margem, StatusAprovacao status, String justificativa) {
        return new ResultadoPrecificacao(preco, desconto, margem, status, justificativa);
    }
}*/

package controller;

import model.RegraPreco;
import model.ResultadoPrecificacao;

public class PricingEngineController {

    public ResultadoPrecificacao validarMargemLucro(RegraPreco regra, double precoPraticado, double descontoAplicado) {
        if (precoPraticado <= 0) {
            return new ResultadoPrecificacao(0.0, "BLOQ", "Preço de venda inválido.");
        }

        // Cálculo da margem real
        double margemReal = ((precoPraticado - regra.getCusto()) / precoPraticado) * 100;

        // Validação de margem abaixo do mínimo ou negativa
        if (margemReal < regra.getMargemMinima() || precoPraticado < regra.getPrecoMinimo()) {
            return new ResultadoPrecificacao(margemReal, "HARD_STOP", "HARD STOP: Margem ou preço abaixo do mínimo permitido.");
        }

        // Regras de Alçada por faixa de desconto[cite: 1]
        if (descontoAplicado <= 5.0) {
            return new ResultadoPrecificacao(margemReal, "LIBERADO", "Desconto dentro da faixa permitida. Liberação automática[cite: 1].");
        } else if (descontoAplicado > 5.0 && descontoAplicado <= 10.0) {
            return new ResultadoPrecificacao(margemReal, "PENDENTE", "Desconto entre 5% e 10%. Necessária aprovação do Gerente[cite: 1].");
        } else {
            return new ResultadoPrecificacao(margemReal, "HARD_STOP", "HARD STOP: Desconto acima de 10% exige supervisor[cite: 1].");
        }
    }
}
